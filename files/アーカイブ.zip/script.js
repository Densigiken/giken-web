document.addEventListener("DOMContentLoaded",function(){
    onscroll = function () {
        dev.innerHTML = pageYOffset;
    }
    onscroll();
})